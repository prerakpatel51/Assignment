# AI & Tools Appendix

- **Tool & Model**: ChatGPT (GPT-5 Thinking)  
- **Dates Used**: ___________________________

## Purpose & Prompts (copy/paste)
- Prompt 1: _______________________________________________
- Prompt 2: _______________________________________________
- Prompt 3: _______________________________________________

## How AI Helped
- Code scaffolding and error handling improvements.
- Separation of calibration logic (helpers) and UI.
- Robust visualization and JSON schema for grading.
