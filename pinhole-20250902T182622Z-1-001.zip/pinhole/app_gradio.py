# app_gradio.py  (SAFE: single-output functions, no DownloadButton)

import os, glob, shutil
import numpy as np
import gradio as gr

from calibration_utils import IO, Calib, Overlay, Render, Img

IS_COLAB = os.path.exists("/content")
BASE_DIR = "/content" if IS_COLAB else os.getcwd()
IMG_DIR = os.path.join(BASE_DIR, "images")
OUT_JSON = os.path.join(BASE_DIR, "calibration.json")
IO.ensure_dir(IMG_DIR)

def save_uploads(files):
    for f in glob.glob(os.path.join(IMG_DIR, "*")):
        try: os.remove(f)
        except: pass
    saved = 0
    if files:
        for i, src in enumerate(files):  # filepath strings
            if src and os.path.exists(src):
                base = os.path.splitext(os.path.basename(src))[0] + ".jpg"
                shutil.copy(src, os.path.join(IMG_DIR, f"calib_{i:03d}_{base}"))
                saved += 1
    return f"Saved {saved} image(s) to {IMG_DIR}"

def test_detection(cols, rows):
    try:
        paths = IO.list_images(IMG_DIR)
        pattern = (int(cols), int(rows))
        det_ok, missed = 0, []
        for p in paths:
            rgb = IO.imread_rgb(p)
            if rgb is None: 
                continue
            ok, _ = Img.find_corners(Img.to_gray(rgb), pattern)
            det_ok += int(ok)
            if not ok: missed.append(os.path.basename(p))
        msg = [f"Pattern {pattern}: detected in {det_ok}/{len(paths)} images."]
        if missed: msg.append("Missed (first 10): " + ", ".join(missed[:10]))
        if det_ok < 5: msg.append(f"Try swapped pattern {(pattern[1], pattern[0])}.")
        return "\n".join(msg)
    except Exception as e:
        import traceback; return f"Detection test failed:\n{e}\n\n{traceback.format_exc()}"

def run_calibration(cols, rows, square_size_m):
    try:
        paths = IO.list_images(IMG_DIR)
        if len(paths) < 5:
            return f"Only {len(paths)} images in {IMG_DIR}. Need ≥5."

        pattern = (int(cols), int(rows))
        square_size_m = float(square_size_m)

        # friendly pre-check
        det_ok = 0
        for p in paths:
            rgb = IO.imread_rgb(p)
            if rgb is None: continue
            ok, _ = Img.find_corners(Img.to_gray(rgb), pattern)
            det_ok += int(ok)
        if det_ok < 5:
            return (f"Detected corners in only {det_ok}/{len(paths)} images with pattern {pattern}. "
                    f"Try {(rows, cols)} or retake clearer shots.")

        result = Calib.calibrate(paths, pattern_size=pattern, square_size=square_size_m)
        IO.save_json(result, OUT_JSON)

        K = np.array(result["K"]); D = np.array(result["D"])
        msg = [
            f"Saved calibration to: {OUT_JSON}",
            f"Views used: {result['num_views']}",
            f"Image size: {result['image_size']}",
            f"RMS reprojection error: {result['ret_rms']:.4f}",
            f"Mean per-view error: {result['mean_reproj_error']:.4f}",
            f"K (intrinsics):\n{K}",
            f"D (distortion): {D}",
            "",
            "Tip: In Colab, open the Files panel (left sidebar) to download calibration.json.",
        ]
        return "\n".join(msg)
    except Exception as e:
        import traceback; return f"Calibration failed:\n{e}\n\n{traceback.format_exc()}"

def show_poses_and_overlays(max_overlays, use_plotly=True, axis_scale=3.0, draw_corners=False, anchor="origin"):
    if not os.path.exists(OUT_JSON): return None, [], None
    calib = IO.load_json(OUT_JSON)
    K = np.array(calib["K"], float); D = np.array(calib["D"], float)
    cols = int(calib["pattern_size"]["cols"]); rows = int(calib["pattern_size"]["rows"])
    square = float(calib["square_size_m"])
    extr = calib.get("extrinsics", [])
    paths = calib.get("valid_paths", []) or IO.list_images(IMG_DIR)

    fig = Render.plot_poses_plotly(extr, square_size=square, board_size=(cols, rows)) if use_plotly \
          else Render.plot_poses_matplotlib(extr, square_size=square, board_size=(cols, rows))
    overlays = Overlay.make_sample_overlays(
        paths, K, D, (cols, rows), square,
        max_images=int(max_overlays), axis_scale=float(axis_scale),
        draw_corners=bool(draw_corners), anchor=anchor,
    )
    gallery = [img for (_p, img) in overlays]
    und = None
    if paths:
        samp = IO.imread_rgb(paths[0])
        if samp is not None:
            und_s = Calib.undistort(samp, K, D, keep_size=True)
            pad = np.ones((samp.shape[0], 10, 3), dtype=np.uint8)*255
            und = np.hstack([samp, pad, und_s])
    return fig, gallery, und

def create_interface():
    with gr.Blocks(title="Camera Calibration (OpenCV + Gradio)", theme=gr.themes.Soft()) as demo:
        gr.Markdown(
            "## Camera Calibration (OpenCV + Gradio)\n"
            "Upload chessboard images, run calibration, and visualize results.\n"
            "- Images: **/content/images** (Colab) or `./images`\n"
            "- Results: **calibration.json** in project root\n"
            "- Pattern size = INNER corners (e.g., 9×6)\n"
        )
        with gr.Row():
            uploader = gr.Files(label="Upload .jpg/.jpeg/.png images", file_types=["image"], type="filepath")
            upload_btn = gr.Button("Save to images/")
        upload_msg = gr.Textbox(label="Upload Log", interactive=False)

        with gr.Accordion("Calibration Parameters", open=True):
            with gr.Row():
                cols = gr.Number(value=9, label="Inner corners (cols)", precision=0)
                rows = gr.Number(value=6, label="Inner corners (rows)", precision=0)
                sq   = gr.Number(value=0.025, label="Square size (meters)")
            with gr.Row():
                test_btn = gr.Button("Test detection (no calibration)")
                run_btn  = gr.Button("Run Calibration", variant="primary")
            calib_out = gr.Textbox(label="Calibration Output", lines=12, interactive=False)

        with gr.Accordion("Visualizations", open=True):
            with gr.Row():
                max_ov = gr.Slider(3, 12, value=6, step=1, label="Max overlay images")
                use_plotly = gr.Checkbox(value=True, label="Interactive 3D (Plotly)")
                axis_scale = gr.Slider(1, 10, value=3, step=0.5, label="Axis scale (× square size)")
                draw_corners = gr.Checkbox(value=True, label="Draw detected corners")
                anchor = gr.Dropdown(choices=["origin", "center"], value="origin", label="Axes anchor")
            pose_plot = gr.Plot(label="Camera Poses (3D)")
            gallery   = gr.Gallery(label="Sample images with axes", columns=3, height=300)
            und_img   = gr.Image(label="Undistort Preview (left=original, right=undistorted)")
            viz_btn   = gr.Button("Generate Visualizations")

        upload_btn.click(save_uploads, inputs=[uploader], outputs=[upload_msg])
        test_btn.click(test_detection, inputs=[cols, rows], outputs=[calib_out])
        run_btn.click(run_calibration, inputs=[cols, rows, sq], outputs=[calib_out])
        viz_btn.click(show_poses_and_overlays,
                      inputs=[max_ov, use_plotly, axis_scale, draw_corners, anchor],
                      outputs=[pose_plot, gallery, und_img])
    return demo

if __name__ == "__main__":
    demo = create_interface()
    demo.launch(share=True, debug=True)
